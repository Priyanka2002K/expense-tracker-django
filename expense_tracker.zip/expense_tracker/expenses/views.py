from rest_framework import viewsets
from .models import Expenses
from .serializers import ExpensesSerializer
import requests
from rest_framework.response import Response
from rest_framework.decorators import api_view
from django.db.models import Sum
from django.db.models.functions import TruncMonth

class ExpensesViewser(viewsets.ModelViewSet):
    queryset=Expenses.objects.all()
    serializer_class = ExpensesSerializer


@api_view(['GET'])

def exchange_rate(request):
    url="https://api.exchangerate-api.com/v4/latest/USD"
    response =requests.get(url)
    data=requests.json()
    return Response({

        "USD_to_INR": data["rates"]["INR"]

    })

@api_view(['GET'])
def monthly_report(resuest):
    report=(
        Expenses.objects.annotate(month=TruncMonth("created_at"))
        .values("month")
        .annotate(Sum("amount"))
        .order_by("month")
    )
    return Response(report)
