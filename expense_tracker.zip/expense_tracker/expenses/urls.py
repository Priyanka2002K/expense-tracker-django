from rest_framework.routers import DefaultRouter
from .views import ExpensesViewser
from .views import exchange_rate
from .views import monthly_report
from django.urls import path

router=DefaultRouter()
router.register('expenses',ExpensesViewser,basename='expenses')

urlpatterns=router.urls




urlpatterns+=[
    path('exchange_rate/',exchange_rate),
    path('monthly_report/',monthly_report),
]